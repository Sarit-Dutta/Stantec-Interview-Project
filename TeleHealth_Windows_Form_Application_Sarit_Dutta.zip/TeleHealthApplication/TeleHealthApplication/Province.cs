﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleHealthApplication
{
    // Class used to define the provinces within the dropdown box in the client form.
    public class Province
    {
        public int ID { get; set; }
        public string Text { get; set; }
    }
}
