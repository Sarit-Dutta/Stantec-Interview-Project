﻿namespace TeleHealthApplication
{
    internal class usernameLabel
    {
    }
}